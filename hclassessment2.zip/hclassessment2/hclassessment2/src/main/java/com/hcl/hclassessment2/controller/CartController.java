package com.hcl.hclassessment2.controller;

import com.hcl.hclassessment2.entity.Cart;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/carts")
public class CartController {


    @PostMapping
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        // Cart savedCart = cartService.save(cart);
        return new ResponseEntity<>(cart, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Cart>> getAllCarts() {
        // List<Cart> carts = cartService.findAll();
        List<Cart> mockList = new ArrayList<>();
        return new ResponseEntity<>(mockList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cart> getCartById(@PathVariable("id") Long id) {
        // Cart cart = cartService.findById(id);
        return new ResponseEntity<>(new Cart(), HttpStatus.OK);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Cart> updateCart(@PathVariable("id") Long id, @RequestBody Cart cartDetails) {
        // Cart updatedCart = cartService.update(id, cartDetails);
        return new ResponseEntity<>(cartDetails, HttpStatus.OK);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCart(@PathVariable("id") Long id) {
        // cartService.delete(id);
        return new ResponseEntity<>("Cart deleted successfully with ID: " + id, HttpStatus.OK);
    }
}


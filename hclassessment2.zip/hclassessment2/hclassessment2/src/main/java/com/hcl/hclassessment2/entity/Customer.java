package com.hcl.hclassessment2.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerid;

    @NotBlank
    private String customerName;

    @Column(unique = true)
    private String email;
    private String password;
    private String mobile;
    private String city;






}

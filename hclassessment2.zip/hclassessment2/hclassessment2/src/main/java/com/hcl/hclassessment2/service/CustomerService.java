package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
    }

    public Customer updateCustomer(Long id, Customer customerDetails) {
        Customer existingCustomer = getCustomerById(id);

        existingCustomer.setCustomerName(customerDetails.getCustomerName());
        existingCustomer.setEmail(customerDetails.getEmail());
        existingCustomer.setPassword(customerDetails.getPassword());
        existingCustomer.setMobile(customerDetails.getMobile());
        existingCustomer.setCity(customerDetails.getCity());

        return customerRepository.save(existingCustomer);
    }

    public void deleteCustomer(Long id) {
        Customer existingCustomer = getCustomerById(id);
        customerRepository.delete(existingCustomer);
    }
}
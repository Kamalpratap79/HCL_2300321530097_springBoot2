
package com.hcl.hclassessment2.controller;

import com.hcl.hclassessment2.entity.Customer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {


    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        // Customer savedCustomer = customerService.save(customer);
        return new ResponseEntity<>(customer, HttpStatus.CREATED);
    }


    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        // List<Customer> customers = customerService.findAll();
        List<Customer> mockList = new ArrayList<>();
        return new ResponseEntity<>(mockList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable("id") Long id) {
        // Customer customer = customerService.findById(id);
        return new ResponseEntity<>(new Customer(), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("id") Long id, @RequestBody Customer customerDetails) {
        // Customer updatedCustomer = customerService.update(id, customerDetails);
        return new ResponseEntity<>(customerDetails, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable("id") Long id) {
        // customerService.delete(id);
        return new ResponseEntity<>("Customer deleted successfuly with ID: " + id, HttpStatus.OK);
    }
}
package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public Cart createCart(Cart cart) {

        if (cart.getCreatedDate() == null) {
            cart.setCreatedDate(LocalDate.now());
        }
        return cartRepository.save(cart);
    }

    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }

    public Cart getCartById(Long id) {
        return cartRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cart not found with id: " + id));
    }

    public Cart updateCart(Long id, Cart cartDetails) {
        Cart existingCart = getCartById(id);

        existingCart.setCustomer(cartDetails.getCustomer());
        existingCart.setCreatedDate(cartDetails.getCreatedDate());

        return cartRepository.save(existingCart);
    }

    public void deleteCart(Long id) {
        Cart existingCart = getCartById(id);
        cartRepository.delete(existingCart);
    }
}


package com.hcl.hclassessment2.controller;

import com.hcl.hclassessment2.entity.Product;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {


    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        // Product savedProduct = productService.save(product);
        return new ResponseEntity<>(product, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        // List<Product> products = productService.findAll();
        List<Product> mockList = new ArrayList<>();
        return new ResponseEntity<>(mockList, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") Long id) {
        // Product product = productService.findById(id);
        return new ResponseEntity<>(new Product(), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable("id") Long id, @RequestBody Product productDetails) {
        // Product updatedProduct = productService.update(id, productDetails);
        return new ResponseEntity<>(productDetails, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") Long id) {
        // productService.delete(id);
        return new ResponseEntity<>("Product deleted successfully with ID: " + id, HttpStatus.OK);
    }
}